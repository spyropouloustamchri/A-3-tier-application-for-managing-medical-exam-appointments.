
package webproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Patient extends Users {

	private final int AMKA;
	private List<String> oldAppointments = new ArrayList<>();
	protected List<String> loadingAppointments = new ArrayList<>();

	protected List<Prescription> prescriptions = new ArrayList<>(); // Ιατρικές συνταγές
	
	// ασθενή

	public Patient() {
		super("", "", "", "", 0, "");
		this.AMKA = 0;
	}

	public Patient(boolean r) {
		super("", "", "", "", 0, "");
		if (r) {
			this.AMKA = registration();
		} else {
			this.AMKA = 0;
		}
	}
	public String showPatient() {
	    return "SELECT * FROM Patient"; // κάτι τέτοιο
	}

	public Patient(String username, String password, String name, String surname, int age, String mail, int AMKA) {
		super(username, password, name, surname, age, mail);
		this.AMKA = AMKA;
	}

	protected int registration() {
		Scanner snr = new Scanner(System.in);
		System.out.println("Για να εγγραφείτε εισάγετε επιθυμητό username:");
		String pname = snr.nextLine();
		setUsername(pname);

		System.out.println("Πληκτρολογήστε έναν κωδικό πρόσβασης:");
		String pcode = snr.nextLine();
		setPassword(pcode);

		System.out.println("Όνομα:");
		String ponoma = snr.nextLine();
		setName(ponoma);

		System.out.println("Επώνυμο:");
		String pnickname = snr.nextLine();
		setSurname(pnickname);

		int page;
		while (true) {
			try {

				System.out.println("Ηλικία:");
				page = Integer.parseInt(snr.nextLine());
				setAge(page);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Παρακαλώ δώστε την ηλικία σε αριθμούς!");
			}
		}

		System.out.println("Ηλεκτρονική διεύθυνση:");
		String pemail = snr.nextLine();
		setMail(pemail);

		int pAMKA;
		while(true) {
		try{
			System.out.println("ΑΜΚΑ :");
			pAMKA =Integer.parseInt(snr.nextLine());
			break;
		}catch(NumberFormatException e) {
			 System.out.println("Παρακαλώ δώστε τον ΑΜΚΑ σε αριθμούς!");
			}
		}
       
		System.out.println("Σας ευχαριστούμε για την εγγραφή σας ασθενή:  " + pname + " " + pnickname + " ! ");
		return pAMKA;
	}

	protected void searchAppointmentSpecificDr(List<Doctor> drs) {
		boolean flag = false;
		int k = 0;
		int n = 0;
		boolean flag3 = false;
		String surname = "";
		System.out.println(
				"Για ποιον γιατρό επιθυμείτε να αναζητήσετε διαθεσιμότητα ραντεβού;/n Οι γιατροί είναι οι εξής:");
		for (Doctor element : drs) {
			System.out.println(element);
		}
		Scanner doctor = new Scanner(System.in);
		String d = doctor.nextLine();
		for (Doctor dc : drs) {
			if (dc.getSurname().equalsIgnoreCase(d)) {
				flag = true;
				surname = getSurname();
				break;
			}

		}
		if (flag) {
			System.out.println("Ο γιατρός βρέθηκε!");
			System.out.println("Διαθέσιμα ραντεβού γιατρού: ");
			for (Doctor d1 : drs) {
				k++;
				if (d1.getSurname() == d) {
					break;
				}
			}
			for (Doctor d1 : drs) {
				n++;
				if (n == k) {
					flag3 = true;
					if (!d1.getAppointments().isEmpty()) {
						int m = 0;
						for (List<String> monthap : d1.getAppointments()) {
							m++;
							System.out.println("Για τον μήνα: " + m + " : \n");
							for (String appointment : d1.getAppointments().get(monthap.size() - 1)) {
								System.out.println(appointment);
							}
						}
						break;
					}
				}

			}
			if (flag3 = false) {
				System.out.println("Δεν υπάρχουν διαθέσιμα ραντεβού. Θα σας ειδοποιήσουμε για νεότερα.");
			}

		} else {
			System.out.println("O γιατρός δεν βρέθηκε στο σύστημά μας. Προσπαθήστε ξανά");
		}

	}

	protected void availableAppointmentGeneralDr(List<Doctor> drs) {
		boolean flag1 = false;
		Scanner snr = new Scanner(System.in);
		System.out.println("Για ποιά ειδικότητα γιατρού ενδιαφέρεστε;");
		String specialty = snr.nextLine();
		for (Doctor dc : drs) {
			if (dc.getSpecialty().equalsIgnoreCase(specialty)) {
				if (!dc.getAppointments().isEmpty()) {
					flag1 = true;
					System.out.println(
							"Διαθέσιμα ραντεβού με τον γιατρό " + dc.getName() + " " + dc.getSurname() + " : ");
					int k = 0;
					for (List<String> monthap : dc.getAppointments()) {
						k++;
						System.out.println("Για τον μήνα: " + k + ": \n");
						for (String appointment : monthap) {
							System.out.println(appointment);
						}
					}
				}
			}
		}
		if (flag1 == false) {
			System.out.println("Κανένας γιατρός αυτής της ειδικότητας δεν έχει διαθέσιμα ραντεβού.");
		}

	}

	protected void seeAppointments() {
		int j = 0;
		if (loadingAppointments.isEmpty()) {
			System.out.println("Δεν έχετε κλείσει κάποιο ραντεβού.");
		} else {
			for (String radevu : loadingAppointments) {
				j++;
				System.out.println(j + "." + "Το ραντεβού σας " + radevu);
			}
		}
	}

	protected void seeHistoryOfAppointments() {
		if (oldAppointments == null) {
			System.out.println("Δεν υπάρχει ιστορικό με ραντεβού");
		} else {
			for (String radevu : oldAppointments) {
				System.out.println(radevu);
			}
		}

	}

	protected void cancelAppointment(List<String> loadingAppointments) {

		Scanner scr = new Scanner(System.in);
		System.out.println("Ποιό ραντεβού επιθυμείτε να ακυρώσετε; Πατήστε το αντίστοιχο νούμερο: ");
		seeAppointments();
		int appoint = scr.nextInt();
		scr.nextLine();
		if (appoint > 0 & appoint <= loadingAppointments.size()) {
			String remove = loadingAppointments.remove(appoint - 1);
			System.out.println("Το ραντεβού " + remove + " ακυρώθηκε με επιτυχία");

		} else {
			System.out.println("Μη έγκυρη επιλογή ραντεβού.");
		}
	}

	public List<String> getloadingAppointments() {
		return loadingAppointments;
	}

	public int getAMKA() {
		return AMKA;
	}
	
	private void txt_erwthma6() {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("patient.txt"))) {
			writer.write("MarJ 1234 Maria Johnson 34 marj@gmail.com 2310 ");
		} catch (IOException e) {
			e.printStackTrace();
		}

		try (BufferedReader reader = new BufferedReader(new FileReader("patient.txt"))) {
			String line = reader.readLine();
			String[] data = line.split(" ");
			String pname = data[0];
			String pcode = data[1];
			String ponoma = data[2];
			String psurname = data[3];
			int page = Integer.parseInt(data[4]);
			String pemail = data[5];
			int pAMKA = Integer.parseInt(data[6]);
			Patient patient = new Patient(pname, pcode, ponoma, psurname, page, pemail, pAMKA);
			System.out.println(data[0] + data[1] + data[3] + data[4]);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

