package webproject;

public class Payment {

	private int service;
	private Patient p;
	
	
	public Payment( int service, Patient p) {
		this.service = service;
		this.p = p;
	}
	
	public int amountPayment() {
		if (service == 1) {
			return 30;
		} else if (service ==2) {
			return 40;
		} else if (service ==3) {
			return 50;
		} else if (service ==4) {
			return 60;
		} else {
			return 10;
		}
	}
	
	public int getService() {
		return service;
	}
	
	public String getPatient() {
		return p.getUsername();
	}
	
}
	
