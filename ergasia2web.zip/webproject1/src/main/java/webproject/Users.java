package webproject;
public class Users {

private String username;
private String password;
private String name;
private String surname;

//πρόσθετα 
private int age;
    private String mail;
    private static int usersCounter=0;
    
    public Users(String username,String password,String name,String surname,int age,String mail) {
    this.username=username;
    this.password=password;
    this.name=name;
    this.surname=surname;
    this.age=age;
    this.mail=mail;
    Users.usersCounter++;
    }
    public Users() {
        this.username=username;
        this.password=password;
        this.name=name;
        this.surname=surname;
        this.age=age;
        this.mail=mail;
        Users.usersCounter++;
        }
    protected void login() {
    System.out.println("Ο χρήστης" + username + " συνδέθηκε επιτυχώς !");
    }
    
    protected void logout() {
    System.out.println("Ο χρήστης" + username + " αποσυνδέθηκε επιτυχώς !");
    System.exit(0);
    }
    public String showUsers() {
	    return "SELECT * FROM Users"; // κάτι τέτοιο
	}
    //! Δε θα βάλω getters n setters στα εξής:
    //α)password(δε θέλω να αλλάζει εύκολα(setters),ούτε να διαβάζεται (getters)).
    //β)usersCounter(μόνο ο κατασκευαστής ευθύνεται για τη τιμή αυτή,δε θέλω να αλλάξει από κανέναν και να επηρεαστεί η ακριβής σειρά)
    
    public void setUsername(String username) {
    this.username=username;
    }
    public void setName(String name) {
    this.name=name;
    }
    public void setSurname(String surname) {
    this.surname=surname;
    }
    public void setAge(int age) {
    this.age=age;
    }
    public void setMail(String mail) {
    this.mail=mail;
    }
    
    protected void setPassword(String password) {
    this.password =password;
    }
    
    
    public String getUsername() {
    return username;
    }
    public String getName() {
    return name;
    }
    public String getSurname() {
    return surname;
    }
    public int getAge() {
    return age;
    }
    public String getMail() {
    return mail;
    }

}
