
package webproject;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Doctor extends Users {
private String specialty;
	
	//επιπλέον χαρακτηριστικά
	private final int AMKA;

	protected List<String> monthAv = new ArrayList<>();
	protected List<List<String>> programmRadevu = new ArrayList<>();
	
	public Doctor( String username,String password,String name,String surname,int age,String mail,int AMKA,String specialty) {
		super(username,password,name,surname,age,mail);
		this.AMKA=AMKA;
		this.specialty=specialty;
		
		//Αρχικοποίηση λίστας ραντεβού
		for(int j=0; j<12;j++) {
			programmRadevu.add(new ArrayList<>());
		}
	}
	//default
	public Doctor() {
		super("","","","",0,"");
		this.AMKA=0;
		this.specialty="";
		
		//Αρχικοποίηση λίστας ραντεβού
		for(int j=0; j<12;j++) {
			programmRadevu.add(new ArrayList<>());
		}
	}
	//Καταχώρηση διαθέσιμων ραντεβού ανά μήνα
	protected void newAppointments_dc(int month, String randevou) {
		if (month >=1 && month<=12) {
			programmRadevu.get(month-1).add(randevou);
			System.out.println("Καταχώρηση ραντεβού με επιτυχία!");
		} else {
			System.out.println("Μη έγκυρος αριθμός μήνα - πρέπει να επιλέξεις αριθμό απο το 1 έως το 12");
		}
	}
	
	//Προβολή διαθεσιμότητας γιατρού για ραντεβού
	
	protected void monthlyAvailability(int month) {
		
		switch(month) {
		
		case 1:
			System.out.println("Διαθέσιμα ραντεβού για τον Γενάρη:\n");
			for(String appointment : programmRadevu.get(0)) {
				System.out.println(appointment);
			}
			break;
		case 2:
			System.out.println("Διαθέσιμα ραντεβού για τον Φλεβάρη:");
			for(String appointment : programmRadevu.get(1)) {
				System.out.println(appointment);
			}
			break;
		case 3:
			System.out.println("Διαθέσιμα ραντεβού για τον Μάρτη:");
			for(String appointment : programmRadevu.get(2)) {
				System.out.println(appointment);
			}
			break;
		case 4:
			System.out.println("Διαθέσιμα ραντεβού για τον Απρίλη:");
			for(String appointment : programmRadevu.get(3)) {
				System.out.println(appointment);
			}
			break;
		case 5:
			System.out.println("Διαθέσιμα ραντεβού για τον Μάη:");
			for(String appointment : programmRadevu.get(4)) {
				System.out.println(appointment);
			}
			break;
		case 6:
			System.out.println("Διαθέσιμα ραντεβού για τον Ιούνιο:");
			for(String appointment : programmRadevu.get(5)) {
				System.out.println(appointment);
			}
			break;
		case 7:
			System.out.println("Διαθέσιμα ραντεβού για τον Ιούλιο:");
			for(String appointment : programmRadevu.get(6)) {
				System.out.println(appointment);
			}
			break;
		case 8:
			System.out.println("Διαθέσιμα ραντεβού για τον Αύγουστο:");
			for(String appointment : programmRadevu.get(7)) {
				System.out.println(appointment);
			}
			break;
		case 9:
			System.out.println("Διαθέσιμα ραντεβού για τον Σεπτέμβρη:");
			for(String appointment : programmRadevu.get(8)) {
				System.out.println(appointment);
			}
			break;
		case 10:
			System.out.println("Διαθέσιμα ραντεβού για τον Οκτώβρη:");
			for(String appointment : programmRadevu.get(9)) {
				System.out.println(appointment);
				
			}
			break;
		case 11:
			System.out.println("Διαθέσιμα ραντεβού για τον Νοέμβρη:");
			for(String appointment : programmRadevu.get(10)) {
				System.out.println(appointment);
			}
			break;
		case 12:
			System.out.println("Διαθέσιμα ραντεβού για τον Δεκέμβρη:");
			for(String appointment : programmRadevu.get(11)) {
				System.out.println(appointment);
			}
			break;
		default:
			System.out.println("Λάθος καταχώρηση μήνα. Προσπαθήστε ξανά");
			break;
		}
	}
	public List <List<String>> getAppointments() {
		return programmRadevu;
	}
	
	public String getSpecialty() {
		return specialty;
	}

	@Override 
	public String toString() {
		return this.getSurname();
	}

	
}

