
package webproject;
import java.util.ArrayList;
import java.util.List;

public class Appointment {

protected List<String>YourAppointment = new ArrayList<>();
	
	private String dateTime;
	private Doctor d;
	
    
	public Appointment(String dateTime,Doctor d) {
    	this.dateTime =dateTime;
    	this.d=d;
    }
    
    protected void YourAppointment(List<String> monthAv) {
    	if(monthAv.isEmpty()) {
    		System.out.println("Δε θα καταφέρετε να κλείσετε ραντεβού");
    	}else {
    		
    	}
    	
    	
    
    }
}
