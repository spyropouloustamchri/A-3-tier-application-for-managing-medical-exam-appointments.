
package webproject;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

public class Admin extends Users{


	
	protected List<Doctor>drs=new ArrayList<>(); //Λίστα γιατρών στο σύστημα
   
	//protected List<Doctor>generaldrs=new ArrayList<>();
	
	public Admin (String username,String password,String name,String surname,int age,String mail) {
		super(username,password,name,surname,age,mail);
	}
	
	//Εισαγωγή γιατρών στο σύστημα
	
	protected void insertDr() {
		Scanner snr = new Scanner(System.in);
		System.out.println("\nΕισαγωγή γιατρών στο σύστημα: ");
		
		System.out.println("Username γιατρού :");
		String drname = snr.nextLine();
		
		System.out.println("Κωδικός :");
		String drcode =snr.nextLine();
		
		System.out.println("Κύριο όνομα :");
		String dronoma =snr.nextLine();
		
		System.out.println("Επώνυμο :");
		String drnickname =snr.nextLine();
		
		System.out.println("Ηλικία :");
		int drage =snr.nextInt();
		snr.nextLine();
		
		System.out.println("Ηλεκτρονική διεύθυνση :");
		String dremail =snr.nextLine();
		
		System.out.println("ΑΜΚΑ :");
		int drAMKA =snr.nextInt();
		snr.nextLine();
		
		System.out.println("Ειδικότητα γιατρού :");
		String drspecialty =snr.nextLine();
		Doctor dtr =new Doctor(drname,drcode,dronoma,drnickname,drage,dremail,drAMKA,drspecialty);
		
		System.out.println("\n");
		drs.add(dtr);
		System.out.println("Καλωσήρθατε στο σύστημά μας:  " + dtr.getName()+ " " + dtr.getSurname());
	}
	
	//Οι επιπλέον μέθοδοι της κλάσης
	
	private void view_patients() {
		System.out.println("Οι εγγεγραμμένοι ασθενείς του συστήματος είναι:");
		//Προβολή ονομάτων
	}
	
	private void view_doctors() {
		System.out.println("Οι καταχωρημένοι γιατροί του συστήματος είναι:");
		for (Doctor d : drs) {
			System.out.println(d.getName()+ " " + d.getSurname());
		}
		
	}
	
	//πρόσβαση(για να καλεσω τη μεθοδο της κλασης patient στην main που δεχεται ως παραμετρο τη λίστα των γιατρων)
	public List<Doctor> getdrs(){
		return drs;
	}
	
}
