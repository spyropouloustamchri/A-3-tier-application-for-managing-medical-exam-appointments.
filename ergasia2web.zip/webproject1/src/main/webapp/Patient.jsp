<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, javax.naming.*, javax.sql.*"%>
<%@ page import="webproject.Patient"%>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="design.css" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Βιοιατρική-Είσοδος</title>
</head>
<body>
	<%
	Connection con = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	String username = (String) session.getAttribute("username");
    String password = (String) session.getAttribute("password");
	
	out.println("<style>");
	out.println("html, body {");
	out.println("  height: 100%;");
	out.println("  margin: 0;");
	out.println("  padding: 0;");
	out.println("}");
	out.println("body {");
	out.println("  background-image: url('img/health.jpg');");
	out.println("  background-size: cover;");
	out.println("  background-repeat: no-repeat;");
	out.println("  background-position: center center;");
	out.println("  font-family: Arial, sans-serif;");
	out.println("  color: white;");
	out.println("  display: flex;");
	out.println("  justify-content: center;");
	out.println("  align-items:center;");
	out.println("  flex-direction: column;");
	out.println("}");
	out.println("</style>");

	out.println("<div style=\"position: absolute; right: 50px; top: 168px; width: 500px;\">");

	out.println("<h2 style='color: white;'>Η σύνδεση ήταν επιτυχής!</h2>");

	out.println("<p>Καλώς ήρθες, " + username + ".</p>");

	out.println("<br>");
	out.println("<form method='post' action='PatientServlet'>");
	out.println("<input type='hidden' name='requestType' value='showDetails'/>");
	out.println("<input type='submit' value='Προβολή των στοιχείων σας' style='padding: 10px 20px; '/>");
	out.println("</form>");
	out.println("<br>");
	out.println("<form method='post' action='PatientServlet'>");
	out.println("<input type='hidden' name='requestType' value='showAppointments'/>");
	out.println("<input type='submit' value='Προβολή ιστορικού ραντεβού' style='padding: 10px 20px;'/>");
	out.println("</form>");
	out.println("<br>");
	out.println("<form method='post' action='PatientServlet'>");
	out.println("<input type='hidden' name='requestType' value='KenaAppointments'/>");
	out.println("<input type='submit' value='Προβολή κενών ραντεβού και Κλείσιμο Ραντεβού' style='padding: 10px 20px;'/>");
	out.println("</form>");
	out.println("<br>");
	out.println("<form method='post' action='PatientServlet'>");
	out.println("<input type='hidden' name='requestType' value='AkurwnwAppointments'/>");
	out.println("<input type='submit' value='Ακύρωση ραντεβού' style='padding: 10px 20px;'/>");
	out.println("</form>");
	out.println("<br>");
	out.println("<form method='post' action='PatientServlet'>");
	out.println("<input type='hidden' name='requestType' value='logout'/>");
	out.println("<input type='submit' value='Αποσύνδεση' style='padding: 10px 20px;'/>");
	out.println("</form>");
	out.println("</div>");
	%>

</body>
</html>
