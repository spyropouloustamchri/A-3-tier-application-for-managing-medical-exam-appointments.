package webprojectServlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "Η σύνδεση γίνεται μόνο μέσω POST.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String requestType = request.getParameter("requestType");

		// login
		if (requestType == null || "Insert".equals(requestType)) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String role = request.getParameter("role");

			Connection con = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String str;

			if (role.equals("Patient")) {
				str = "SELECT password, salt, amka, name, surname FROM Patient WHERE username = ?";
			} else if (role.equals("Doctor")) {
				str = "SELECT password, salt, amka, name, surname FROM Doctor WHERE username = ?";
			} else {
				str = "SELECT password, salt, amka, name, surname FROM Admin WHERE username = ?";
			}

			try {
				InitialContext ctx = new InitialContext();
				DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
				con = ds.getConnection();

				String sql = str;
				stmt = con.prepareStatement(sql);
				stmt.setString(1, username);
				rs = stmt.executeQuery();

				out.println("<!DOCTYPE html>");
				out.println("<html><head><title>Βιοιατρική-Κεντρική</title></head><body>");

				if (rs.next()) {

					String storedHash = rs.getString("password");
					String salt = rs.getString("salt");

					String inputHash = hashPassword(password, salt);

					if (storedHash.equals(inputHash)) {
						if (role.equals("Patient")) {
							HttpSession session = request.getSession();
							session.setAttribute("username", username);
							session.setAttribute("password", password);
							response.sendRedirect("Patient.jsp");
						} else if (role.equals("Doctor")) {
							HttpSession session = request.getSession();
							session.setAttribute("username", username);
							session.setAttribute("password", password);
							response.sendRedirect("Doctor.jsp");
						} else {
							HttpSession session = request.getSession();
							session.setAttribute("username", username);
							session.setAttribute("password", password);
							response.sendRedirect("Admin.jsp");
						}
					} else {
						out.println("<style>");
						out.println("html, body {");
						out.println("  height: 100%;");
						out.println("  margin: 0;");
						out.println("  padding: 0;");
						out.println("}");
						out.println("body {");
						out.println("  background-image: url('img/health.jpg');");
						out.println("  background-size: cover;");
						out.println("  background-repeat: no-repeat;");
						out.println("  background-position: center center;");
						out.println("  font-family: Arial, sans-serif;");
						out.println("  color: white;");
						out.println("  display: flex;");
						out.println("  justify-content: center;");
						out.println("  align-items:center;");
						out.println("  flex-direction: column;");
						out.println("}");
						out.println("</style>");

						out.println("<div style=\"position: absolute; right: 50px; top: 168px; width: 500px;\">");
						out.println("<h2 style='color: white;'>Αποτυχία σύνδεσης.</h2>");
						out.println("<p>Λάθος όνομα χρήστη ή κωδικός.</p>");
						out.println("</div>");
					}
				}

				out.println("</body></html>");

			} catch (Exception e) {
				out.println("<h2>Σφάλμα: " + e.getMessage() + "</h2>");
			} finally {
				try {
					if (rs != null)
						rs.close();
				} catch (SQLException e) {
				}
				try {
					if (stmt != null)
						stmt.close();
				} catch (SQLException e) {
				}
				try {
					if (con != null)
						con.close();
				} catch (SQLException e) {
				}
			}
		}

		// Εγγραφή
		if (requestType == null || "SignUp".equals(requestType)) {
			out.println("<html><head><title>Εγγραφή στο σύστημα </title></head><body>");
			out.println(
					"<style>body {background-image: url('img/health.jpg'); background-size: cover; color: white; display: flex; justify-content: center; align-items:center; flex-direction: column;}</style>");
			out.println("<div style=\"position: absolute; right: 50px; top: 168px; width: 500px;\">"
					+ "<form method=\"post\" action=\"UserServlet\">\r\n"
					+ "    <input type=\"hidden\" name=\"requestType\" value=\"Εγγραφή\" />\r\n" + "   \r\n"
					+ "    <table>\r\n" + "        <tr>\r\n" + "            <td><b>Όνομα Χρήστη:</b></td>\r\n"
					+ "            <td><input type=\"text\" name=\"username\" /></td>\r\n" + "        </tr>\r\n"
					+ "        <tr>\r\n" + "            <td><b>Κωδικός:</b></td>\r\n"
					+ "            <td><input type=\"password\" name=\"password\" /></td>\r\n" + "        </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Name:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"name\" /></td>\r\n" + "       </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Surname:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"surname\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Age:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"age\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Email:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"email\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Amka:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"amka\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n"
					+ "					<td><b>Ρόλος:</b></td>\r\n"
					+ "					<td><select id=\"role\" name=\"role\">\r\n"
					+ "							<option value=\"\" disabled selected>Επιλέξτε Ρόλο</option>\r\n"
					+ "							<option value=\"Patient\">Ασθενής</option>\r\n"
					+ "							<option value=\"Doctor\">Γιατρός</option>\r\n"
					+ "							<option value=\"Admin\">Διαχειριστής</option>\r\n"
					+ "					</select></td>\r\n"
					+ "				</tr>\r\n"
					    

					+ "        <tr>\r\n" + "            <td></td>\r\n"
					+ "            <td><input type=\"submit\" value=\"Εγγραφή\" /></td>\r\n" + "        </tr>\r\n"
					+ "    </table>\r\n" + "</form>");
			out.println("</div></body></html>");
		}

		if ("Εγγραφή".equals(requestType)) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String salt = generateSalt();
			String role = request.getParameter("role");
			String str;

			String hashedPassword = null;
			try {
				hashedPassword = hashPassword(password, salt);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String name = request.getParameter("name");
			String surname = request.getParameter("surname");
			String age = request.getParameter("age");
			String email = request.getParameter("email");
			String amka = request.getParameter("amka");

			Connection con = null;
			PreparedStatement insertUserStmt = null;
			PreparedStatement insertPatientStmt = null;
			PreparedStatement insertDoctorStmt = null;
			PreparedStatement insertAdminStmt = null;

			try {
				InitialContext ctx = new InitialContext();
				DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
				con = ds.getConnection();

				// Αποθήκευση στον πίνακα Users
				String insertUserSQL = "INSERT INTO Users (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				insertUserStmt = con.prepareStatement(insertUserSQL);
				insertUserStmt.setString(1, username);
				insertUserStmt.setString(2, hashedPassword);
				insertUserStmt.setString(3, name);
				insertUserStmt.setString(4, surname);
				insertUserStmt.setInt(5, Integer.parseInt(age));
				insertUserStmt.setString(6, email);
				insertUserStmt.setString(7, amka);
				insertUserStmt.setString(8, salt);
				insertUserStmt.executeUpdate();

				if (role.equals("Patient")) {
					// Αποθήκευση στον πίνακα Patient
					String insertPatientSQL = "INSERT INTO Patient (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

					insertPatientStmt = con.prepareStatement(insertPatientSQL);
					insertPatientStmt.setString(1, username);
					insertPatientStmt.setString(2, hashedPassword);
					insertPatientStmt.setString(3, name);
					insertPatientStmt.setString(4, surname);
					insertPatientStmt.setInt(5, Integer.parseInt(age));
					insertPatientStmt.setString(6, email);
					insertPatientStmt.setString(7, amka);
					insertPatientStmt.setString(8, salt);
					insertPatientStmt.executeUpdate();
				} else if (role.equals("Doctor")) {
					String insertPatientSQL = "INSERT INTO Doctor (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

					insertDoctorStmt = con.prepareStatement(insertPatientSQL);
					insertDoctorStmt.setString(1, username);
					insertDoctorStmt.setString(2, hashedPassword);
					insertDoctorStmt.setString(3, name);
					insertDoctorStmt.setString(4, surname);
					insertDoctorStmt.setInt(5, Integer.parseInt(age));
					insertDoctorStmt.setString(6, email);
					insertDoctorStmt.setString(7, amka);
					insertDoctorStmt.setString(8, salt);
					insertDoctorStmt.executeUpdate();
				} else {
					String insertPatientSQL = "INSERT INTO Admin (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

					insertAdminStmt = con.prepareStatement(insertPatientSQL);
					insertAdminStmt.setString(1, username);
					insertAdminStmt.setString(2, hashedPassword);
					insertAdminStmt.setString(3, name);
					insertAdminStmt.setString(4, surname);
					insertAdminStmt.setInt(5, Integer.parseInt(age));
					insertAdminStmt.setString(6, email);
					insertAdminStmt.setString(7, amka);
					insertAdminStmt.setString(8, salt);
					insertAdminStmt.executeUpdate();
				}

				// Επιτυχής εγγραφή
				out.println("<html><body><h2>Η εγγραφή ήταν επιτυχής!</h2>");

			} catch (Exception e) {
				out.println("<html><body><h2>Σφάλμα κατά την εγγραφή: " + e.getMessage() + "</h2></body></html>");
			} finally {
				try {
					if (insertUserStmt != null)
						insertUserStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (insertPatientStmt != null)
						insertPatientStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (insertDoctorStmt != null)
						insertDoctorStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (insertAdminStmt != null)
						insertAdminStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (con != null)
						con.close();
				} catch (SQLException e) {
				}
			}
		}

	}

	private String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		return Base64.getEncoder().encodeToString(salt);
	}

	private String hashPassword(String password, String salt) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String saltedPassword = password + salt;
		byte[] hash = md.digest(saltedPassword.getBytes());
		return Base64.getEncoder().encodeToString(hash);
	}
}
