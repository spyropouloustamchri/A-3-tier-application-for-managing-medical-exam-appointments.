package webprojectServlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String requestType = request.getParameter("requestType");

		// Εγγραφή/Εισαγωγή γιατρού
		if (requestType == null || "AddDr".equals(requestType)) {
			out.println("<html><head><title>Εγγραφή στο σύστημα </title></head><body>");
			out.println(
					"<style>body {background-image: url('img/health.jpg'); background-size: cover; color: white; display: flex; justify-content: center; align-items:center; flex-direction: column;}</style>");
			out.println("<div style=\"position: absolute; right: 50px; top: 168px; width: 500px;\">"
					+ "<form method=\"post\" action=\"AdminServlet\">\r\n"
					+ "    <input type=\"hidden\" name=\"requestType\" value=\"Εγγραφή γιατρού\" />\r\n" + "   \r\n"
					+ "    <table>\r\n" + "        <tr>\r\n" + "            <td><b>Όνομα Χρήστη:</b></td>\r\n"
					+ "            <td><input type=\"text\" name=\"username\" /></td>\r\n" + "        </tr>\r\n"
					+ "        <tr>\r\n" + "            <td><b>Κωδικός:</b></td>\r\n"
					+ "            <td><input type=\"password\" name=\"password\" /></td>\r\n" + "        </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Name:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"name\" /></td>\r\n" + "       </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Surname:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"surname\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Age:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"age\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Email:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"email\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Amka:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"amka\" /></td>\r\n" + "       </tr>\r\n"
					+ "            <td><input type=\"submit\" value=\"Εγγραφή\" /></td>\r\n" + "        </tr>\r\n"
					+ "    </table>\r\n" + "</form>");
			out.println("</div></body></html>");
		}

		if ("Εγγραφή γιατρού".equals(requestType)) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String salt = generateSalt();
			String role = "Doctor";
			String str;

			String hashedPassword = null;
			try {
				hashedPassword = hashPassword(password, salt);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String name = request.getParameter("name");
			String surname = request.getParameter("surname");
			String age = request.getParameter("age");
			String email = request.getParameter("email");
			String amka = request.getParameter("amka");

			Connection con = null;
			PreparedStatement insertUserStmt = null;
			PreparedStatement insertDoctorStmt = null;

			try {
				InitialContext ctx = new InitialContext();
				DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
				con = ds.getConnection();

				// Αποθήκευση στον πίνακα Users
				String insertUserSQL = "INSERT INTO Users (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				insertUserStmt = con.prepareStatement(insertUserSQL);
				insertUserStmt.setString(1, username);
				insertUserStmt.setString(2, hashedPassword);
				insertUserStmt.setString(3, name);
				insertUserStmt.setString(4, surname);
				insertUserStmt.setInt(5, Integer.parseInt(age));
				insertUserStmt.setString(6, email);
				insertUserStmt.setString(7, amka);
				insertUserStmt.setString(8, salt);
				insertUserStmt.executeUpdate();

				String insertDoctorSQL = "INSERT INTO Doctor (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

				insertDoctorStmt = con.prepareStatement(insertDoctorSQL);
				insertDoctorStmt.setString(1, username);
				insertDoctorStmt.setString(2, hashedPassword);
				insertDoctorStmt.setString(3, name);
				insertDoctorStmt.setString(4, surname);
				insertDoctorStmt.setInt(5, Integer.parseInt(age));
				insertDoctorStmt.setString(6, email);
				insertDoctorStmt.setString(7, amka);
				insertDoctorStmt.setString(8, salt);
				insertDoctorStmt.executeUpdate();

				// Επιτυχής εγγραφή
				out.println("<html><body><h2>Η εγγραφή ήταν επιτυχής!</h2>");

			} catch (Exception e) {
				out.println("<html><body><h2>Σφάλμα κατά την εγγραφή: " + e.getMessage() + "</h2></body></html>");
			} finally {
				try {
					if (insertUserStmt != null)
						insertUserStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (insertDoctorStmt != null)
						insertDoctorStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (con != null)
						con.close();
				} catch (SQLException e) {
				}
			}
		}

		// Εγγραφή/Εισαγωγή ασθενή
		if (requestType == null || "AddPatient".equals(requestType)) {
			out.println("<html><head><title>Εγγραφή στο σύστημα </title></head><body>");
			out.println(
					"<style>body {background-image: url('img/health.jpg'); background-size: cover; color: white; display: flex; justify-content: center; align-items:center; flex-direction: column;}</style>");
			out.println("<div style=\"position: absolute; right: 50px; top: 168px; width: 500px;\">"
					+ "<form method=\"post\" action=\"AdminServlet\">\r\n"
					+ "    <input type=\"hidden\" name=\"requestType\" value=\"Εγγραφή ασθενή\" />\r\n" + "   \r\n"
					+ "    <table>\r\n" + "        <tr>\r\n" + "            <td><b>Όνομα Χρήστη:</b></td>\r\n"
					+ "            <td><input type=\"text\" name=\"username\" /></td>\r\n" + "        </tr>\r\n"
					+ "        <tr>\r\n" + "            <td><b>Κωδικός:</b></td>\r\n"
					+ "            <td><input type=\"password\" name=\"password\" /></td>\r\n" + "        </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Name:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"name\" /></td>\r\n" + "       </tr>\r\n"
					+ "         <tr>\r\n" + "           <td><b>Surname:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"surname\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Age:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"age\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Email:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"email\" /></td>\r\n" + "       </tr>\r\n"

					+ "         <tr>\r\n" + "           <td><b>Amka:</b></td>\r\n"
					+ "           <td><input type=\"text\" name=\"amka\" /></td>\r\n" + "       </tr>\r\n"
					+ "            <td><input type=\"submit\" value=\"Εγγραφή\" /></td>\r\n" + "        </tr>\r\n"
					+ "    </table>\r\n" + "</form>");
			out.println("</div></body></html>");
		}

		if ("Εγγραφή ασθενή".equals(requestType)) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String salt = generateSalt();
			String role = "Patient";
			String str;

			String hashedPassword = null;
			try {
				hashedPassword = hashPassword(password, salt);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String name = request.getParameter("name");
			String surname = request.getParameter("surname");
			String age = request.getParameter("age");
			String email = request.getParameter("email");
			String amka = request.getParameter("amka");

			Connection con = null;
			PreparedStatement insertUserStmt = null;
			PreparedStatement insertPatientStmt = null;

			try {
				InitialContext ctx = new InitialContext();
				DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
				con = ds.getConnection();

				// Αποθήκευση στον πίνακα Users
				String insertUserSQL = "INSERT INTO Users (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				insertUserStmt = con.prepareStatement(insertUserSQL);
				insertUserStmt.setString(1, username);
				insertUserStmt.setString(2, hashedPassword);
				insertUserStmt.setString(3, name);
				insertUserStmt.setString(4, surname);
				insertUserStmt.setInt(5, Integer.parseInt(age));
				insertUserStmt.setString(6, email);
				insertUserStmt.setString(7, amka);
				insertUserStmt.setString(8, salt);
				insertUserStmt.executeUpdate();

				String insertPatientSQL = "INSERT INTO Patient (username, password, name, surname, age, email, amka, Salt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

				insertPatientStmt = con.prepareStatement(insertPatientSQL);
				insertPatientStmt.setString(1, username);
				insertPatientStmt.setString(2, hashedPassword);
				insertPatientStmt.setString(3, name);
				insertPatientStmt.setString(4, surname);
				insertPatientStmt.setInt(5, Integer.parseInt(age));
				insertPatientStmt.setString(6, email);
				insertPatientStmt.setString(7, amka);
				insertPatientStmt.setString(8, salt);
				insertPatientStmt.executeUpdate();

				// Επιτυχής εγγραφή
				out.println("<html><body><h2>Η εγγραφή ήταν επιτυχής!</h2>");

			} catch (Exception e) {
				out.println("<html><body><h2>Σφάλμα κατά την εγγραφή: " + e.getMessage() + "</h2></body></html>");
			} finally {
				try {
					if (insertUserStmt != null)
						insertUserStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (insertPatientStmt != null)
						insertPatientStmt.close();
				} catch (SQLException e) {
				}
				try {
					if (con != null)
						con.close();
				} catch (SQLException e) {
				}
			}
		}

		if ("DltDr".equals(requestType)) {
			HttpSession session = request.getSession(false);
			out.println("<!DOCTYPE html>");
			out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");

			out.println("<style>");
			out.println("html, body {");
			out.println("}");
			out.println("body {");
			out.println("  background-color: #95adc9;");
			out.println("}");
			out.println("</style>");

			out.println("<h1>Διαγραφή Γιατρού</h1>" + "<form action=\"" + request.getContextPath()
					+ "/AdminServlet\" method=\"post\">"
					+ "<input type=\"hidden\" name=\"requestType\" value=\"DltDrr\">"
					+ "          <input type=\"text\" id=\"username\" name=\"username\">\r\n"
					+ "          <input type=\"submit\" value=\"Διαγραφή\" >" + "        </form>");

		}

		// Διαγραφή γιατρού
		if ("DltDrr".equals(requestType)) {

			String username = request.getParameter("username");

			try (Connection con1 = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection()) {
				// Πάρε το όνομα του γιατρού πρώτα
				PreparedStatement stmt = con1.prepareStatement("SELECT * FROM Doctor WHERE username = ?");
				stmt.setString(1, username);
				ResultSet rs = stmt.executeQuery();

				if (rs.next()) {
					username = rs.getString("username");
				} else {
					out.println("<p>Δεν βρέθηκε γιατρός με αυτό το username.</p>");
					return;
				}

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (NamingException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			try (Connection con1 = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection()) {

				try (PreparedStatement deleteDoctorStmt = con1
						.prepareStatement("DELETE FROM Doctor WHERE username = ?")) {

					deleteDoctorStmt.setString(1, username);
					deleteDoctorStmt.executeUpdate();

					out.println("<html><body><h2>Η ακύρωση ήταν επιτυχής.</h2></body></html>");
				} catch (Exception e) {

				}

				try (PreparedStatement deleteUserStmt = con1.prepareStatement("DELETE FROM Users WHERE username = ?")) {

					deleteUserStmt.setString(1, username);
					deleteUserStmt.executeUpdate();

				} catch (Exception e) {

				}

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}

		}
       
		//Αποσύνδεση
		
		if("logout".equals(requestType)) {
			HttpSession session = request.getSession(false);
			session.invalidate();
			response.sendRedirect("menu.jsp");
		}

	}

	private String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		return Base64.getEncoder().encodeToString(salt);
	}

	private String hashPassword(String password, String salt) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String saltedPassword = password + salt;
		byte[] hash = md.digest(saltedPassword.getBytes());
		return Base64.getEncoder().encodeToString(hash);
	}

}
