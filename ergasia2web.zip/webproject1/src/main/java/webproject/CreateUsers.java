package webproject;
import java.util.List;
import java.util.Scanner;


public class CreateUsers {

	public static void main(String args[]) {

		Scanner snr = new Scanner(System.in);

		System.out.println("Username διαχειριστή:\n");
		String diaxeirisths = snr.nextLine();

		System.out.println("Κωδικός:\n");
		String code = snr.nextLine();

		System.out.println("Όνομα:\n");
		String onoma = snr.nextLine();

		System.out.println("Επώνυμο :");
		String epwnymo = snr.nextLine();

		System.out.println("Ηλικία :");
		int hlikia = snr.nextInt();
		snr.nextLine();

		System.out.println("Ηλεκτρονική διεύθυνση :");
		String email = snr.nextLine();
		
        
		Admin a = new Admin(diaxeirisths, code, onoma, epwnymo, hlikia, email);
		
        Patient p =new Patient(false);
        Doctor d =new Doctor();
        a.insertDr();
		
        //MENU
        while (true) {
			
			System.out.println("1. Είμαι ασθενής");
			System.out.println("2. Είμαι γιατρός");

			int choice = snr.nextInt();
			snr.nextLine();

			if (choice == 1) {
				while (true) {
					// μενού για χρήστη

					System.out.println("Επιλέξτε: \n");
					System.out.println("Με το 1. Εγγράφεστε");
					System.out.println("Με το 2. Αναζητάτε ραντεβού με συγκεκριμένο γιατρό");
					System.out.println("Με το 3. Αναζητάτε ραντεβού με με οποιονδήποτε γιατρό μιας ειδικότητας");
					System.out.println("Με το 4. Βλέπετε αν έχετε κλείσει κάποιο ραντεβού και ποιο είναι αυτό");
					System.out.println("Με το 5. Βλέπετε το ιστορικό των ραντεβού σας αν αυτό υπάρχει");
					System.out.println("Με το 6. Ακυρώνετε κάποιο ραντεβού");
					System.out.println("Με το 7. Αποσυνδέεστε");

					int choiceI = snr.nextInt();
					snr.nextLine();

					if (choiceI == 1) {
						System.out.println("\n");
						p.registration();
						break;
					} else if (choiceI == 2) {
						System.out.println("\n");
						p.searchAppointmentSpecificDr(a.getdrs());
						break;
					}else if (choiceI == 3) {
						System.out.println("\n");
						p.availableAppointmentGeneralDr(a.getdrs());
						break;
					} else if (choiceI == 4) {
						System.out.println("\n");
						p.seeAppointments();
						break;
					} else if (choiceI == 5) {
						System.out.println("\n");
						p.seeHistoryOfAppointments();
						break;
					} else if (choiceI == 6) {
						System.out.println("\n");
					    p.cancelAppointment(p.getloadingAppointments());
					    break;
					} else if (choiceI == 7) {
						System.out.println("\n");
						p.logout();
						break;
					}
				}

			} else if (choice == 2) {
				while (true) {
					// μενού για γιατρό
					System.out.println("Με το 1. Καταχώρηση διαθεσιμότητάς σας ανά μήνα");
					System.out.println("Με το 2. Προβολή διαθεσιμότητάς σας για ραντεβού");
					System.out.println("Με το 3. Αποσυνδέεστε");

					int choiceII = snr.nextInt();
					snr.nextLine();
					if (choiceII == 1) {
						System.out.println("\n");
						Scanner sn = new Scanner(System.in);
						System.out.println("Εισάγετε έναν αριθμό από 1-12 :");
						 int month = sn.nextInt();
						 sn.nextLine();
						 System.out.println("Εισάγετε με ακρίβεια τις ημέρες του μήνα και τις ώρες που θα είστε διαθέσιμος :");
						String randevou=sn.nextLine();
						d.newAppointments_dc(month,randevou);
						break;
					} else if (choiceII == 2) {
						System.out.println("\n");
						Scanner sn = new Scanner(System.in);
						System.out.println("Εισάγετε έναν αριθμό από 1-12 :");
						 int month = sn.nextInt();
						 d.monthlyAvailability(month);
						 break;
					} else if (choiceII == 3) {
						System.out.println("\n");
						d.logout();
						break;
					} else {
						break;
					}
				}
			}
		}
	}
}