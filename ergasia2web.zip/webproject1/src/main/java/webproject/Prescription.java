
package webproject;

import java.util.Scanner;
import java.util.Random;

public class Prescription {
	private static int prescr_id=0;
	private String DoctorFullName;
	private String PatientFullName;
	private String illness;
	
	public Prescription() {
		details();
	}
	
	public void details() {
		Scanner snr = new Scanner(System.in);
		System.out.println("Πληκτρολογήστε πληροφορίες ιατρικής συνταγής:\n");
		System.out.println("Όνοματεπώνυμο γιατρού: ");
		String dname = snr.nextLine();
		setDoctorFullName(dname);
		System.out.println("\n Ονοματεπώνυμο παραλήφθη: ");
		String pname = snr.nextLine();
		setPatientFullName(pname);
		System.out.println("\n Όνομα ασθένειας: ");
		String illname = snr.nextLine();
		setIllness(illname);
		System.out.println("Το αίτημα σας για ιατρική συνταγή καταγράφηκε!");
		this.prescr_id++;
		System.out.println("Κωδικός εκτέλεσης συνταγής: " + prescr_id);
		
	}
	
	public void setDoctorFullName(String dname) {
		this.DoctorFullName = dname;
	}
	
	public void setPatientFullName(String dpatient) {
		this.PatientFullName = dpatient;
	}
	
	public void setIllness(String iname) {
		this.illness = iname;
	}
}

