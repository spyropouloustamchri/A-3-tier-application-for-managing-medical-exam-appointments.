<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, javax.naming.*, javax.sql.*"%>
<%@ page import="webproject.Users"%>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="design.css" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Βιοιατρική-Είσοδος</title>
</head>
<body>
	<%
	DataSource datasource = null;
	Connection con = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	Users u = new Users();
	try {
		InitialContext ctx = new InitialContext();
		datasource = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
		con = datasource.getConnection();
		stmt = con.prepareStatement(u.showUsers()); 
		rs = stmt.executeQuery();
	
	
	} catch (Exception e) {
	%>
	<p>
		Σφάλμα κατά τη σύνδεση με τη βάση δεδομένων:
		<%=e.getMessage()%></p>
	<%
	} finally {
	if (rs != null)
		try {
			rs.close();
		} catch (SQLException e) {
		}
	if (stmt != null)
		try {
			stmt.close();
		} catch (SQLException e) {
		}
	if (con != null)
		try {
			con.close();
		} catch (SQLException e) {
		}
	}
	%>


	</table>
	<!--Φόρμα εισαγωγής χρήστη-->
	<br />
	<hr />
	<br />
	<a name="insert"></a>
	<h2>Είσοδος Χρήστη</h2>
	<center>
		<img src="img/bioiatriki.png" width="600">

		<form method="post" action="UserServlet">
			<input type="hidden" name="requestType" value="Insert" />

			<table>
				<tr>
					<td><b>Όνομα Χρήστη:</b></td>
					<td><input type="text" name="username" /></td>
				</tr>
				<tr>
					<td><b>Κωδικός:</b></td>
					<td><input type="password" name="password" /></td>
				</tr>
				<tr>
					<td><b>Ρόλος:</b></td>
					<td><select id="role" name="role">
							<option value="" disabled selected>Επιλέξτε Ρόλο</option>
							<option value="Patient">Ασθενής</option>
							<option value="Doctor">Γιατρός</option>
							<option value="Admin">Διαχειριστής</option>
					</select></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Σύνδεση" /></td>
				</tr>
			</table>
		</form>

		<form method="post" action="UserServlet">
			<input type="hidden" name="requestType" value="SignUp" />
			<table>
				<tr>
					<td></td>
					<td><input type="submit" value="Εγγραφή" /></td>
				</tr>
			</table>
		</form>
	</center>
</body>
</html>
