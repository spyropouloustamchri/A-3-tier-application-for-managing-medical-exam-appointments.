package webprojectServlets;

import jakarta.servlet.ServletException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

@WebServlet("/DoctorServlet")
public class DoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DoctorServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String requestType = request.getParameter("requestType");

		if ("AddAppointments".equals(requestType)) {
			HttpSession session = request.getSession(false);
			out.println("<!DOCTYPE html>");
			out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");
			out.println("<style>");
			out.println("html, body {");
			out.println("}");
			out.println("body {");
			out.println("  background-color: #95adc9;");
			out.println("}");
			out.println("</style>");

			out.println("<h1>Καταχώρηση Ραντεβού</h1>" + "<form action=\"" + request.getContextPath()
					+ "/DoctorServlet\" method=\"post\">"
					+ "<input type=\"hidden\" name=\"requestType\" value=\"AddAppointment\">"
					+ "          <label for=\"radevu\">Μηνιαία:</label>\r\n"
					+ "          <input type=\"date\" id=\"radevu\" name=\"radevu\">\r\n" + "<tr>\r\n"
					+ "					<td><b>Ειδικότητα:</b></td>\r\n"
					+ "					<td><select id=\"specialty\" name=\"specialty\">\r\n"
					+ "							<option value=\"\" disabled selected>Επιλέξτε Ειδικότητα</option>\r\n"
					+ "							<option value=\"Cardiologist\">Καρδιολόγος</option>\r\n"
					+ "							<option value=\"Psychiatrist\">Ψυχίατρος</option>\r\n"
					+ "							<option value=\"Pediatrician\">Παιδίατρος</option>\r\n"
					+ "							<option value=\"Dermatologist\">Δερματολόγος</option>\r\n"
					+ "							<option value=\"Neurologist\">Νευρολόγος</option>\r\n"
					+ "							<option value=\"Gastroenterologist\">Γαστρεντερολόγος</option>\r\n"
					+ "					</select></td>\r\n" + "				</tr>\r\n"
					+ "          <input type=\"submit\" value=\"Καταχώρηση\" >" + "        </form>");

		}

		// Καταχωρηση ραντεβου
		if ("AddAppointment".equals(requestType)) {
			// Date date =new Date();
			String date = request.getParameter("radevu");
			String specialty = request.getParameter("specialty");

			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			String username = (String) session.getAttribute("username");

			Connection con = null;
			;

			try (Connection con1 = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt = con1.prepareStatement("SELECT * FROM Doctor WHERE username = ?")) {

				stmt.setString(1, username);
				ResultSet rs = stmt.executeQuery();
				String dr_name = null;
				String doctor_id = null;
				if (rs.next()) {
					dr_name = rs.getString("name");
					doctor_id = rs.getString("amka");

				} else {
					out.println("<p>Δεν βρέθηκε γιατρός με αυτό το username.</p>");
				}

				PreparedStatement insertAppointmentsStmt = null;
				try {
					InitialContext ctx = new InitialContext();
					// DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/LiveDataSource");
					// con = ds.getConnection();

					// Αποθήκευση στον πίνακα Users
					String insertAppointmentsSQL = "INSERT INTO Appointments (date, dr_name, doctor_id, specialty) VALUES (?, ?, ?, ?)";
					insertAppointmentsStmt = con1.prepareStatement(insertAppointmentsSQL);
					insertAppointmentsStmt.setString(1, date);
					insertAppointmentsStmt.setString(2, dr_name);
					insertAppointmentsStmt.setString(3, doctor_id);
					insertAppointmentsStmt.setString(4, specialty);

					insertAppointmentsStmt.executeUpdate();
					out.println("<html><body><h2>Η εγγραφή ήταν επιτυχής!</h2>");
				} catch (Exception e) {
					out.println("<html><body><h2>Σφάλμα κατά την καταχώρηση ραντεβού: " + e.getMessage()
							+ "</h2></body></html>");
				} finally {
					try {
						if (insertAppointmentsStmt != null)
							insertAppointmentsStmt.close();
					} catch (SQLException e) {

					}
				}

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}
		}

		// Εμφανιση Ραντεβου (σαν ιστορικο ασθενους η λογικη)
		if ("ShowAppointments".equals(requestType)) {

			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			String username = (String) session.getAttribute("username");

			try (Connection con = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt = con.prepareStatement(
							"SELECT * FROM Appointments ,Doctor WHERE Appointments.doctor_id=Doctor.amka AND username = ?")) {

				stmt.setString(1, username);
				ResultSet rs = stmt.executeQuery();

				out.println("<!DOCTYPE html>");
				out.println("<html><head><title>Βιοιατρική-Πινακάς Ραντεβού</title></head><body>");

				out.println("<style>");
				out.println("html, body {");
				out.println("}");
				out.println("body {");
				out.println("  background-color: #95adc9;");
				out.println("}");
				out.println("td {");
				out.println("padding: 20px");
				out.println("}");
				out.println("th {");
				out.println("  padding: 15px;");
				out.println("  background-color: #3B64A0;");
				out.println("  color: white;");
				out.println("}");
				out.println("</style>");

				out.println("<br>");
				out.println("<div style=\"position: absolute; top: 168px;  left: 350px;\">");

				out.println("<center>");
				out.println("<h1>Πίνακας Ραντεβού</h1>");
				out.println("</center>");
				out.println("<br>");
				out.println(
						"<table border='4'><tr><th>Ημερομηνία</th><th>Όνομα Γιατρού</th><th>Διαθεσιμότητα</th><th>Κωδικός Γιατρού</th><th>Ειδικότητα</th></tr>");

				while (rs.next()) {
					out.println("<tr>");
					out.println("<td>" + rs.getString("date") + "</td>");
					out.println("<td>" + rs.getString("dr_name") + "</td>");
					out.println("<td>" + rs.getString("availability") + "</td>");
					out.println("<td>" + rs.getInt("doctor_id") + "</td>");
					out.println("<td>" + rs.getString("specialty") + "</td>");
					out.println("</tr>");
				}

				out.println("</table></div></body></html>");

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}

			return;
		}

		if ("CancelAppointments".equals(requestType)) {
			HttpSession session = request.getSession(false);
			out.println("<!DOCTYPE html>");
			out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");

			out.println("<style>");
			out.println("html, body {");
			out.println("}");
			out.println("body {");
			out.println("  background-color: #95adc9;");
			out.println("}");
			out.println("</style>");

			out.println("<h1>Ακύρωση Ραντεβού</h1>" + "<form action=\"" + request.getContextPath()
					+ "/DoctorServlet\" method=\"post\">"
					+ "<input type=\"hidden\" name=\"requestType\" value=\"CancelAppointment\">"
					+ "          <label for=\"radevu\">Μηνιαία:</label>\r\n"
					+ "          <input type=\"date\" id=\"radevu\" name=\"radevu\">\r\n"
					+ "          <input type=\"submit\" value=\"Ακύρωση\" >" + "        </form>");

		}

		// Ακύρωση ραντεβού
		if ("CancelAppointment".equals(requestType)) {

			String date = request.getParameter("radevu");
			LocalDate td = LocalDate.now();

			boolean flag = true;

			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			String username = (String) session.getAttribute("username");

			if (date != null && !date.isEmpty()) {
				try {
					LocalDate calendarDate = LocalDate.parse(date);
					long daysBetween = ChronoUnit.DAYS.between(td, calendarDate);

					try (Connection con1 = ((DataSource) new InitialContext()
							.lookup("java:comp/env/jdbc/LiveDataSource")).getConnection()) {
						// Πάρε το όνομα του γιατρού πρώτα
						PreparedStatement stmt = con1.prepareStatement("SELECT * FROM Doctor WHERE username = ?");
						stmt.setString(1, username);
						ResultSet rs = stmt.executeQuery();

						String dr_name = null;
						if (rs.next()) {
							dr_name = rs.getString("name");
						} else {
							out.println("<p>Δεν βρέθηκε γιατρός με αυτό το username.</p>");
							return;
						}

						// Τώρα έλεγξε αν υπάρχει ραντεβού για το συγκεκριμένο dr_name και ημερομηνία
						PreparedStatement checkStmt = con1
								.prepareStatement("SELECT * FROM Appointments WHERE dr_name = ? AND date = ?");
						checkStmt.setString(1, dr_name);
						checkStmt.setString(2, date);
						ResultSet checkResult = checkStmt.executeQuery();

						if (!checkResult.next()) {
							out.println(
									"<html><body><h2>Δεν υπάρχει καταχωρημένο ραντεβού για αυτή την ημερομηνία.</h2></body></html>");
							return;
						}

					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (NamingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					if (daysBetween < 3) {
						out.println(
								"<html><body><h2>Η ακύρωση επιτρέπεται μόνο για ραντεβού που απέχουν τουλάχιστον 3 ημέρες.</h2></body></html>");
						flag = false;
					}

					if (flag) {
						String dr_name = null;
						try (Connection con1 = ((DataSource) new InitialContext()
								.lookup("java:comp/env/jdbc/LiveDataSource")).getConnection();
								PreparedStatement stmt = con1
										.prepareStatement("SELECT * FROM Doctor WHERE username = ?")) {

							stmt.setString(1, username);
							ResultSet rs = stmt.executeQuery();

							if (rs.next()) {
								dr_name = rs.getString("name");
							} else {
								out.println("<p>Δεν βρέθηκε γιατρός με αυτό το username.</p>");
								return;
							}

							try (PreparedStatement deleteAppointmentsStmt = con1
									.prepareStatement("DELETE FROM Appointments WHERE dr_name = ? AND date = ?")) {

								deleteAppointmentsStmt.setString(1, dr_name);
								deleteAppointmentsStmt.setString(2, date);
								deleteAppointmentsStmt.executeUpdate();

								out.println("<html><body><h2>Η ακύρωση ήταν επιτυχής.</h2></body></html>");
							}

						} catch (Exception e) {
							out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
						}
					}
				} catch (DateTimeParseException e) {
					out.println("<html><body><h2>Μη έγκυρη ημερομηνία.</h2></body></html>");
				}
			}
		}
		// Αποσύνδεση

		if ("logout".equals(requestType)) {
			HttpSession session = request.getSession(false);
			session.invalidate();
			response.sendRedirect("menu.jsp");
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "Η σύνδεση γίνεται μόνο μέσω POST.");
	}
}
