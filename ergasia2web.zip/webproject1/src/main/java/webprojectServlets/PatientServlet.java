package webprojectServlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

import javax.naming.*;
import javax.sql.DataSource;

@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public PatientServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String requestType = request.getParameter("requestType");

		// Προβολή στοιχείων ασθενή
		if ("showDetails".equals(requestType)) {
			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			String username = (String) session.getAttribute("username");

			try (Connection con = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM Patient WHERE username = ?")) {

				stmt.setString(1, username);
				ResultSet rs = stmt.executeQuery();

				out.println("<!DOCTYPE html>");
				out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");

				out.println("<style>");
				out.println("html, body {");
				out.println("}");
				out.println("body {");
				out.println("  background-color: #95adc9;");
				out.println("}");
				out.println("td {");
				out.println("padding: 20px");
				out.println("}");
				out.println("th {");
				out.println("  padding: 15px;");
				out.println("  background-color: #3B64A0;");
				out.println("  color: white;");
				out.println("}");
				out.println("</style>");

				out.println("<br>");
				out.println("<div style=\"position: absolute; top: 168px;  left: 350px;\">");

				out.println("<center>");
				out.println("<h1>Πίνακας Ασθενών</h1>");
				out.println("</center>");
				out.println("<br>");
				out.println(
						"<table border='4'><tr><th>Όνομα Χρήστη</th><th>Όνομα</th><th>Επώνυμο</th><th>Ηλικία</th><th>Email</th><th>ΑΜΚΑ</th></tr>");

				if (rs.next()) {
					out.println("<tr>");
					out.println("<td>" + rs.getString("username") + "</td>");
					// out.println("<td>" + rs.getString("password") + "</td>");
					out.println("<td>" + rs.getString("name") + "</td>");
					out.println("<td>" + rs.getString("surname") + "</td>");
					out.println("<td>" + rs.getInt("age") + "</td>");
					out.println("<td>" + rs.getString("email") + "</td>");
					out.println("<td>" + rs.getString("amka") + "</td>");
					out.println("</tr>");
				}

				out.println("</table></div></body></html>");

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}

			return;
		}

		// Ιστορικό ραντεβού
		if ("showAppointments".equals(requestType)) {
			HttpSession session1 = request.getSession(false);
			String username = (String) session1.getAttribute("username");
			String Amka = (String) session1.getAttribute("Amka");

			try (Connection con1 = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt1 = con1.prepareStatement("SELECT * FROM Patient WHERE username = ?")) {

				stmt1.setString(1, username);
				ResultSet rs1 = stmt1.executeQuery();

				if (rs1.next()) {
					Amka = rs1.getString("amka");
				} else {
					out.println("<p>Δεν βρέθηκε γιατρός με αυτό το username.</p>");
					return;
				}
			} catch (Exception e) {

			}
			if (session1 == null || Amka == null) {

				out.println("<html><body> <h2>Δεν έχετε κλείσει ακόμη κάποιο ραντεβού.</h2>");
				out.println("<style>");
				out.println("html, body {");
				out.println("}");
				out.println("body {");
				out.println("  background-color: #95adc9;");
				out.println("}");
				out.println("td {");
				out.println("padding: 20px");
				out.println("}");
				out.println("th {");
				out.println("  padding: 15px;");
				out.println("  background-color: #3B64A0;");
				out.println("  color: white;");
				out.println("}");
				out.println("</style>");
				out.println("</body></html>");
				return;
			}

			try (Connection con = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM Historika WHERE Amka = ?")) {

				stmt.setString(1, Amka);
				ResultSet rs = stmt.executeQuery();

				out.println("<!DOCTYPE html>");
				out.println("<html><head><title>Βιοιατρική-Ιστορικό Ραντεβού</title></head><body>");

				out.println("<style>");
				out.println("html, body {");
				out.println("}");
				out.println("body {");
				out.println("  background-color: #95adc9;");
				out.println("}");
				out.println("td {");
				out.println("padding: 20px");
				out.println("}");
				out.println("th {");
				out.println("  padding: 15px;");
				out.println("  background-color: #3B64A0;");
				out.println("  color: white;");
				out.println("}");
				out.println("</style>");

				out.println("<br>");
				out.println("<div style=\"position: absolute; top: 168px;  left: 350px;\">");

				out.println("<center>");
				out.println("<h1>Πίνακας Ιστορικού Ραντεβού ασθενή</h1>");
				out.println("</center>");
				out.println("<br>");
				out.println(
						"<table border='4'><tr><th>ID</th><th>AMKA</th><th>Ημερομηνία Ραντεβού</th><th>Γιατρός</th></tr>");

				while (rs.next()) {
					out.println("<tr>");
					out.println("<td>" + rs.getInt("ID") + "</td>");
					out.println("<td>" + rs.getString("Amka") + "</td>");
					out.println("<td>" + rs.getString("Appointment_date") + "</td>");
					out.println("<td>" + rs.getString("Dr") + "</td>");
					out.println("</tr>");
				}

				out.println("</table></div></body></html>");

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}

			return;
		}

		if ("KenaAppointments".equals(requestType)) {
			HttpSession session = request.getSession(false);
			out.println("<!DOCTYPE html>");
			out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");

			out.println("<style>");
			out.println("html, body {");
			out.println("}");
			out.println("body {");
			out.println("  background-color: #95adc9;");
			out.println("}");
			out.println("</style>");

			out.println("<h1>Διαθέσιμα κενά για κλείσιμο Ραντεβού</h1>" + "<form action=\"" + request.getContextPath()
					+ "/PatientServlet\" method=\"post\">"
					+ "<input type=\"hidden\" name=\"requestType\" value=\"KenaAppointment\">" + "<tr>\r\n"
					+ "					<td><b>Ειδικότητα:</b></td>\r\n"
					+ "					<td><select id=\"specialty\" name=\"specialty\">\r\n"
					+ "							<option value=\"\" disabled selected>Επιλέξτε Ειδικότητα</option>\r\n"
					+ "							<option value=\"Cardiologist\">Καρδιολόγος</option>\r\n"
					+ "							<option value=\"Psychiatrist\">Ψυχίατρος</option>\r\n"
					+ "							<option value=\"Pediatrician\">Παιδίατρος</option>\r\n"
					+ "							<option value=\"Dermatologist\">Δερματολόγος</option>\r\n"
					+ "							<option value=\"Neurologist\">Νευρολόγος</option>\r\n"
					+ "							<option value=\"Gastroenterologist\">Γαστρεντερολόγος</option>\r\n"
					+ "					</select></td>\r\n" + "				</tr>\r\n"
					+ "          <input type=\"submit\" value=\"Προβολή κενών\" >" + "        </form>");

		}

		// Προβολή κενών ραντεβού
		if ("KenaAppointment".equals(requestType)) {

			String specialty = request.getParameter("specialty");

			try (Connection con = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection();
					PreparedStatement stmt = con
							.prepareStatement("SELECT * FROM Appointments  WHERE specialty = ? and availability=1")) {

				stmt.setString(1, specialty);
				ResultSet rs = stmt.executeQuery();

				out.println("<!DOCTYPE html>");
				out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");
				out.println("<style>");
				out.println("html, body {");
				out.println("}");
				out.println("body {");
				out.println("  background-color: #95adc9;");
				out.println("}");
				out.println("td {");
				out.println("padding: 20px");
				out.println("}");
				out.println("th {");
				out.println("  padding: 15px;");
				out.println("  background-color: #3B64A0;");
				out.println("  color: white;");
				out.println("}");
				out.println("</style>");

				out.println("<br>");
				out.println("<div style=\"position: absolute; top: 168px;  left: 350px;\">");

				out.println("<center>");
				out.println("<h1>Προβολή διαθέσιμων Ραντεβού:</h1>");
				out.println("</center>");
				out.println("<br>");
				out.println(
						"<table border='4'><tr><th>Ημερομηνία</th><th>Όνομα Γιατρού</th><th>Διαθεσιμότητα</th><th>Κωδικός Γιατρού</th><th>Ειδικότητα</th></tr>");

				while (rs.next()) {
					out.println("<tr>");
					out.println("<td>" + rs.getString("date") + "</td>");
					out.println("<td>" + rs.getString("dr_name") + "</td>");
					out.println("<td>" + rs.getString("availability") + "</td>");
					out.println("<td>" + rs.getInt("doctor_id") + "</td>");
					out.println("<td>" + rs.getString("specialty") + "</td>");
					out.println("</tr>");

				}
				out.println("</table>");

				out.println("<h1>Επιλέξτε Ραντεβού βάσει του παραπάνω πίνακα:</h1>" + "<form action=\""
						+ request.getContextPath() + "/PatientServlet\" method=\"post\">"
						+ "<input type=\"hidden\" name=\"requestType\" value=\"KleinwAppointment\">"
						+ "          <label for=\"radevu\"><b>Ημερομηνία:</b></label>\r\n"
						+ "          <input type=\"date\" id=\"radevu\" name=\"radevu\">\r\n"
						+ "         <tr>\r\n <b>Όνομα Γιατρού:</b>\r\n"
						+ "			  <input type=\"text\" name=\"Dr\" />" + "          </tr>\r\n"
						+ "          <input type=\"submit\" value=\"Καταχώρηση\" >" + "        </form>");
				out.println("</div></body></html>");

			} catch (Exception e) {
				out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
			}

			return;
		}

		if ("KleinwAppointment".equals(requestType)) {

			String date = request.getParameter("radevu");
			String drName = request.getParameter("Dr");

			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			String username = (String) session.getAttribute("username");

			try (Connection con = ((DataSource) new InitialContext().lookup("java:comp/env/jdbc/LiveDataSource"))
					.getConnection()) {

				// Βρίσκουμε το AMKA του ασθενή
				String amka = null;
				try (PreparedStatement stmt = con.prepareStatement("SELECT amka FROM Patient WHERE username = ?")) {
					stmt.setString(1, username);
					try (ResultSet rs = stmt.executeQuery()) {
						if (rs.next()) {
							amka = rs.getString("amka");
						} else {
							out.println("<html><body><h2>Δεν βρέθηκε ασθενής με αυτό το username.</h2></body></html>");
							return;
						}
					}
				}

				// Ελέγχουμε αν υπάρχει διαθέσιμο ραντεβού
				boolean available = false;
				try (PreparedStatement checkStmt = con.prepareStatement(
						"SELECT * FROM Appointments WHERE dr_name = ? AND date = ? AND availability = 1")) {
					checkStmt.setString(1, drName);
					checkStmt.setString(2, date);
					try (ResultSet rs = checkStmt.executeQuery()) {
						if (rs.next()) {
							available = true;
						}
					}
				}

				if (!available) {
					out.println("<html><body><h2>Το ραντεβού δεν είναι διαθέσιμο ή δεν υπάρχει.</h2></body></html>");
					return;
				}

				// Αν είναι διαθέσιμο -> ενημέρωση και καταχώρηση
				try (PreparedStatement updateStmt = con
						.prepareStatement("UPDATE Appointments SET availability = 0 WHERE dr_name = ? AND date = ?")) {
					updateStmt.setString(1, drName);
					updateStmt.setString(2, date);
					updateStmt.executeUpdate();
				}

				try (PreparedStatement insertStmt = con
						.prepareStatement("INSERT INTO Historika (Amka, Appointment_date, Dr) VALUES (?, ?, ?)")) {
					insertStmt.setString(1, amka);
					insertStmt.setString(2, date);
					insertStmt.setString(3, drName);
					insertStmt.executeUpdate();
				}

				out.println("<html><body><h2>Το ραντεβού καταχωρήθηκε επιτυχώς!</h2></body></html>");

			} catch (Exception e) {
				out.println("<html><body><h2>Σφάλμα κατά την εκτέλεση: " + e.getMessage() + "</h2></body></html>");
			}
		}

		if ("AkurwnwAppointments".equals(requestType)) {
			HttpSession session = request.getSession(false);
			out.println("<!DOCTYPE html>");
			out.println("<html><head><title>Βιοιατρική-Στοιχεία Ασθενή</title></head><body>");

			out.println("<style>");
			out.println("html, body {");
			out.println("}");
			out.println("body {");
			out.println("  background-color: #95adc9;");
			out.println("}");
			out.println("</style>");

			out.println("<h1>Ακύρωση Ραντεβού</h1>" + "<form action=\"" + request.getContextPath()
					+ "/PatientServlet\" method=\"post\">"
					+ "<input type=\"hidden\" name=\"requestType\" value=\"AkurwnwAppointment\">"
					+ "          <label for=\"radevu\">Ημερομηνία:</label>\r\n"
					+ "          <input type=\"date\" id=\"radevu\" name=\"radevu\">\r\n"
					+ "         <tr>\r\n <b>Όνομα Γιατρού:</b>\r\n" + "			  <input type=\"text\" name=\"Dr\" />"
					+ "          </tr>\r\n" + "          <input type=\"submit\" value=\"Ακύρωση\" >"
					+ "        </form>");

		}

		// Ακύρωση ραντεβού
		if ("AkurwnwAppointment".equals(requestType)) {

			String Dr = request.getParameter("Dr");
			String date = request.getParameter("radevu");
			LocalDate td = LocalDate.now();

			HttpSession session = request.getSession(false);
			if (session == null || session.getAttribute("username") == null) {
				out.println("<html><body><h2>Δεν είστε εγγεγραμμένος.</h2></body></html>");
				return;
			}

			// String username = (String) session.getAttribute("username");
			boolean flag = true;

			if (date != null && !date.isEmpty()) {
				long daysBetween;
				try {
					LocalDate calendarDate = LocalDate.parse(date);
					daysBetween = ChronoUnit.DAYS.between(td, calendarDate);

					try (Connection con1 = ((DataSource) new InitialContext()
							.lookup("java:comp/env/jdbc/LiveDataSource")).getConnection()) {

						// Τώρα έλεγξε αν υπάρχει ραντεβού για το συγκεκριμένο dr_name και ημερομηνία
						PreparedStatement checkStmt = con1
								.prepareStatement("SELECT * FROM Historika WHERE Dr = ? AND Appointment_date = ?");
						checkStmt.setString(1, Dr);
						checkStmt.setString(2, date);
						ResultSet checkResult = checkStmt.executeQuery();

						if (daysBetween < 3) {
							out.println(
									"<html><body><h2>Η ακύρωση επιτρέπεται μόνο για ραντεβού που απέχουν τουλάχιστον 3 ημέρες.</h2></body></html>");
							flag = false;
						}

						if (!checkResult.next()) {
							out.println(
									"<html><body><h2>Δεν υπάρχει καταχωρημένο ραντεβού για αυτή την ημερομηνία.</h2></body></html>");
							return;
						}
					} catch (Exception e) {

					}

					if (flag) {
						try (Connection con1 = ((DataSource) new InitialContext()
								.lookup("java:comp/env/jdbc/LiveDataSource")).getConnection()) {

							try (PreparedStatement deleteAppointmentsStmt = con1
									.prepareStatement("DELETE FROM Historika WHERE Dr = ? AND Appointment_date = ?")) {

								deleteAppointmentsStmt.setString(1, Dr);
								deleteAppointmentsStmt.setString(2, date);
								deleteAppointmentsStmt.executeUpdate();

								out.println("<html><body><h2>Η ακύρωση ήταν επιτυχής.</h2></body></html>");
								try (PreparedStatement updateStmt = con1.prepareStatement(
										"UPDATE Appointments SET availability = 1 WHERE dr_name = ? AND date = ?")) {
									updateStmt.setString(1, Dr);
									updateStmt.setString(2, date);
									updateStmt.executeUpdate();
								} catch (Exception e) {
								}

							} catch (Exception e) {
								out.println("<p>Σφάλμα: " + e.getMessage() + "</p>");
							}
						} catch (Exception e) {
						}
					}
				} catch (Exception e) {

				}
			}
		}
		// Αποσύνδεση

		if ("logout".equals(requestType)) {
			HttpSession session = request.getSession(false);
			session.invalidate();
			response.sendRedirect("menu.jsp");
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "Η σύνδεση γίνεται μόνο μέσω POST.");
	}
}
